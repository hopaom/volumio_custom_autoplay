# volumio_custom_autoplay

### A simple autoplay plugin for Volumio 3.  

The autoplay command is configurable in the setting.   
Use the syntax of `/api/v1/replaceAndPlay` (see [API documentation](https://volumio.github.io/docs/API/REST_API.html#page_ADDING_ITEMS_TO_PLAYBACK))
